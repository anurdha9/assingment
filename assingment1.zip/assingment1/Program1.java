package assingment1;

public class Program1 {

	public static void main(String[] args) {
    int a=10;
    int b=12;
    int c=a+b;
    System.out.println(c);
 
	}
}
