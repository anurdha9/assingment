package assingment1;

public class Program3 {
public static void main(String[] args) {
	System.out.println("Anu");
 	}

}
